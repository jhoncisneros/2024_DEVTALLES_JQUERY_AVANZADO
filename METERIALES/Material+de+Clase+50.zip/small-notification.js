

(function($){

  $(document).ready(function(){
    var contenido = '<div id="small-top-left-container"></div>';
    $('body').append(contenido);
  });


  $.smallBox = function(){

    ajustes = {
      titulo: "Hola Mundo",
      contenido: "Saludos, soy un plugin!",
      img: 'assets/img/ball.png'
    }


  }


})(jQuery);
